# Original micro-example: The Wrong Parcel

Illustrative fiction and shot planning only. Not a full reel, tested code or an animation asset.

Premise: A bicycle courier finds a parcel addressed to her own flat, dated tomorrow. She must decide whether to deliver it unopened.

Visible beat: She checks the label, recognizes the address and stops reaching for the doorbell. The parcel shifts in her grip. A faint ticking comes from inside. She turns it over and finds her own handwriting.

Shot plan example, 6 seconds at 30fps, frames 0-179:
0-29: Eyes track across label; head follows slightly. Parcel remains supported by both hands.
30-65: Brows tighten. Right index finger starts toward the bell, elbow unfolding from the shoulder.
66-89: Finger stops before contact. Brief held realization, not six seconds of frozen portrait.
90-139: Gaze moves to parcel; left wrist rotates it while the other hand keeps contact. No detached hands.
140-179: Close-up reveals handwriting. Underline draws along the date. End with a motivated cut.

Narrator versus dialogue: If an off-screen narrator describes the action, her mouth stays at rest. If she says a line in a later approved script, actual dialogue audio and timing are needed for lip-sync.

Feasibility: This requires a courier rig with arm/hand controls and a label prop. With only a fixed portrait, these actions are NOT implemented. A vector-puppet treatment is an option to approve, not an automatic replacement for realism.
