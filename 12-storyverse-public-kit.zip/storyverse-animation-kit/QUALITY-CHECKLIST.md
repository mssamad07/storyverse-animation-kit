# Ready means checked

Mark each item PASS, FAIL, NOT APPLICABLE or UNTESTED. Never turn an untested claim into PASS.

STORY
[ ] Mode is explicit: original fiction / adaptation / personal story.
[ ] Hook, goal, obstacle, choice and payoff are clear.
[ ] No unapproved changes to source, personal events or episode boundary.
[ ] No private real names or imported autobiographical details.
[ ] Narrator and dialogue are clearly separate.

MOTION
[ ] At least start/quarter/middle/three-quarter/end inspected per shot.
[ ] Active character beats change joint pose, gaze or expression, not just crop.
[ ] Hands contact props; limbs stay attached; characters stay grounded.
[ ] Listening reactions and timing differ between characters.
[ ] Whole-scene images with zoom/pan/crossfades are NOT called character animation.
[ ] Glowing name-orbs, books, particles or abstract motifs do not replace requested characters. A motion-graphics-only treatment needs explicit agreement.
[ ] No placeholder components, omitted scene bodies or truncated code blocks presented as a complete project.
[ ] Path, shape or diagram animation clarifies rather than replaces the story.
[ ] Actual motion clips reviewed when execution is available.

CODE / PACKAGE
[ ] Complete source and declared dependencies, no missing placeholders.
[ ] Frame-driven deterministic animation, no wall-clock loops.
[ ] All asset paths resolve locally; rights/attribution recorded.
[ ] No paid API, secret key, generation model or surprise network upload.
[ ] No fake ZIP links, output files, test results or install claims.
[ ] ZIP opens, manifest matches contents, no secrets/caches/node_modules.

AUDIO / DELIVERY
[ ] Actual audio duration measured if supplied.
[ ] No character lip-sync to an off-screen narrator.
[ ] Dialogue lip-sync checked against actual dialogue, if used.
[ ] Mix and pronunciation only marked listened if actually heard.
[ ] Captions readable on a phone, no clipped lines or UI overlap.
[ ] Final dimensions/fps/frame count/duration verified if rendered.
[ ] Limitations stay with the delivered result.

FAILURE RULE
A fixed portrait can be attractive, but captions and crossfades do not make its body act. If only slideshow motion is implemented, label it accurately and return to the missing rig/action task. Do not expand a failed proof into a long final video.
