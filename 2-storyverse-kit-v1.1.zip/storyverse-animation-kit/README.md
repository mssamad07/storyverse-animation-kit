# Storyverse.ai.in Story + Animation Kit

Reusable creative and coding instructions for original stories, timed scripts and full-motion reel projects.

**This is an instruction kit, not a runnable Remotion project, installed extension, rig library or video generator.** It does not guarantee realistic acting, free exports or attachment support in any chat service.

## Defaults in v1.1

Original code-built stylized 2D characters are the default. Free external TTS may receive non-private narration without another routine confirmation. Private/personal text still needs separate permission. Missing stock rigs are not a blocker for code-drawn characters. This version replaces the earlier realistic-asset-first default.

## Use in Gemini or another coding assistant

1. Open `START-HERE.txt`.
2. Download or copy `SKILL.md` and `STORY-WORKFLOW.md` into your chat.
3. Fill `NEW-STORY-BRIEF.txt` for a fresh original story, or `ANIMATION-JOB.txt` for an existing approved script.
4. Review the story first. For an authorized code job, build original stylized 2D rigs in code and use free external TTS for non-private narration. Do not require stock rigs for this default.
5. Use `QUALITY-CHECKLIST.md` to distinguish actual action from image slides and untested promises.

Use GitHub's **Code > Download ZIP** for the whole kit. A coding assistant may read public links, but if it cannot, upload the downloaded files or paste their text. Providing this link does not install a skill.

## What the kit protects against

- Static portraits with zoom/crossfades labelled full character animation.
- Replacing requested people with glowing name-orbs, books or abstract motifs without agreement.
- Characters lip-syncing to an off-screen narrator.
- Placeholder or truncated code presented as a complete project.
- Fabricated test passes, renders and download links.

## Creative scope

New original fiction can use any selected genre. Adaptations and personal stories keep their own approved events, aliases and continuity. No private stories, character assets, reference images, videos or credentials are included.

The default production brief is code-only and zero paid services, without image/video generation models, paid APIs or private uploads. Free external TTS for non-private narration is the audio exception; personal/private text requires separate permission. Missing assets must be reported, not hidden behind a slideshow substitute.

See `CREDITS.txt` for the contents note. This is not an official Google, Gemini, Remotion or Instagram product.
