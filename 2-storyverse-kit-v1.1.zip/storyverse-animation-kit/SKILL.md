# Storyverse.ai.in: original stories and full-motion reels

Use this brief when turning a supplied story script into a runnable animated reel project. The goal is visible action over time, not a sequence of pictures with transitions.

## 1. Keep the agreement

- First choose a story mode. In ORIGINAL FICTION mode, invent a fresh story and dialogue. In ADAPTATION or PERSONAL STORY mode, preserve supplied events, characters and endpoint; label changes and ask before adding plot. Never replace a story with motivational text.
- Code-only and zero paid services. No image/video generation models, paid APIs, subscriptions, trial-credit services or secret keys. Free external TTS is the allowed audio exception for non-private narration, subject to the audio policy below.
- Do not upload private scripts, voices or assets to outside services. For non-private narration only, free external TTS may receive the minimum narration text needed to make the voice. Do not send full projects, source documents or unrelated context.
- A reusable illustration is allowed as a background or rig part. A rendered still of a whole scene is not a substitute for character animation.
- Separate what can actually be built from what would require unavailable assets. Never label an unfinished project or storyboard a finished animated film.

## 2. Check feasibility before building

Inspect the supplied code and assets first. List the character layers/rigs, face controls, audio and fonts that exist, and what is missing.

For full character acting, require separately movable body parts, usable joints, facial controls and consistent character designs. Textures and a body skeleton alone do not prove speaking or expressive acting is possible.

DEFAULT VISUAL STYLE: design original stylized 2D characters directly in code, with hierarchical SVG/vector rigs, distinct silhouettes, joints, eyes and brows. This default is already selected: do not ask for uploaded rigs or style confirmation for an ordinary new story. Missing stock artwork is not a blocker when it can be drawn in code. If an explicit request requires photorealism or supplied likenesses, explain the gap and ask before changing that specific request. Do not substitute still images, stock portraits, crude stick figures, glowing name-orbs, books, particles, abstract motifs or typography for requested character animation. A circle labelled with a character name does not perform that character. Abstract motion graphics are valid only when the user deliberately chooses a motion-graphics-only treatment; label that choice honestly and do not call it character acting. Instructions cannot create missing production-quality art or acting assets by themselves.

DEFAULT AUDIO: create off-screen narration using a genuinely free external TTS option for non-private narration, without asking again for that ordinary use. First check the service terms, availability, limits and whether the job can run without money, credits, secrets or a new account. No free-provider or voice-quality guarantee. If unavailable, explain the actual issue and offer local speech or an audio-ready project, clearly labelled; do not silently deliver a silent final reel. Personal/private narration needs separate permission naming the text and service before disclosure. No voice cloning or impersonation. Preserve supplied audio when requested. Never claim tested lip-sync without testing.

## 3. Write an action plan for every shot

For each shot, specify:
- Start/end frames, speaker and narrative beat.
- Character action with beginning, change and end. Example: a courier checks a parcel label, notices the wrong address, then turns toward the door.
- Listener reaction, gaze target and prop contact.
- The separate animated channels: torso, head, eyes, brows, arms, hands, mouth and camera, where the shot needs them.
- Anticipation, main movement and settling time.

Use motivated movement, not constant wobbling. A held reaction can be still briefly. A hand reaching for a book must actually change pose and reach it; moving the whole portrait across the screen does not count.

## 4. Character animation rules

- Build or use real hierarchical rigs. Shoulder drives upper arm, elbow drives forearm, wrist drives hand. Keep joints attached and respect their bend directions.
- Give every character a distinct identity, outfit, expression range and timing. Never mirror one puppet to create the other.
- Aim eyes and head toward the other character or the relevant prop. Avoid wandering pupils and identical synchronized blinks.
- Use restrained acting: small posture shifts, thoughtful pauses, eyebrow changes and natural turns. Do not cycle the same hand wave through every line.
- Preserve hand/prop contact. Do not let hands pass through books, faces or tables. Keep seated bodies grounded.
- Only move the mouth for a speaking character when actual dialogue audio exists. With narrator-only audio, animate listening/thinking; the characters must not lip-sync to the narrator.
- For dialogue audio, time mouth shapes to phonemes or reviewed word cues. A random opening mouth is not lip-sync. Check audio/video alignment after rendering.
- Keep silhouettes readable at phone size. Do not hide broken joints with aggressive crops or fast cuts.

## 5. Motion-graphics rules

Use graphics to clarify the story, not replace it. For a delivery mystery, a route can draw on in stages while the courier continues checking the parcel. A text label can enter, settle, stay readable and exit.

Animate shape geometry, paths, masks, highlights or diagram parts. Whole-image zoom, crossfade, parallax and camera shake are supporting effects, not the main animation.

Use one consistent easing language. Characters need eased acceleration, overshoot only when motivated, and short settling. Captions should be readable rather than bouncing on every word. Avoid strobing and unnecessary flashes.

## 6. Runnable code contract

Preferred delivery: a complete Remotion project, not pseudocode, placeholders or an output cut off midway. Every referenced component and asset must exist or be explicitly reported missing before delivery. Include package.json, a lockfile, source, local assets, asset credits and clear render instructions. Declare exact working dependency versions; do not claim an install was tested unless it was.

All animation must be a deterministic function of the current frame. Use frame-based interpolation, springs or explicit animation curves. Do not rely on wall-clock time, setInterval, CSS animations that advance independently of frames, or unseeded randomness.

Make duration, fps, dimensions, colors, font, audio path and script easy to change. Put scene timing in one data file. Keep character rigs, scenes, captions and audio in separate components. Use local assets and fonts so the finished project does not depend on remote URLs or network access during rendering.

Do not fetch hidden assets or install unrelated software. Do not include telemetry, credential collection or automatic uploads. No unexpected network calls at render time.

## 7. Prove it is not a slideshow

Before calling the project ready, inspect these frames for every shot: start, quarter, middle, three-quarter and end. Compare poses, joint positions, expression and props. A different camera crop around the same pose is not enough.

Also render short motion checks for each unique rig/action, then review a low-resolution complete draft when execution is available. Inspect actual images and motion, not only the code. If you cannot run the project, mark all render and visual checks UNTESTED. Do not invent passed tests, screenshots or output files.

Check: no frozen character through an entire active conversation shot; no detached limbs; no texture gaps; no hand intersections; no mismatched gaze; no mouth movement for narrator audio; no missing assets; readable captions; no clipping; no blank frames; correct first/last frame; clean audio ending. Hold shots may be quiet, but must be deliberate rather than padding.

Report the precise limitation if quality fails. Do not stretch a failed sample to the requested duration.

## 8. Package and explain honestly

Return a ZIP only if you can create a real downloadable ZIP. Include README.md, source, local assets, credits/licenses and a timing manifest. Exclude node_modules, secrets and caches.

README must state: visual style actually implemented; whether character rigs are genuine; what moves; whether audio exists; what was tested; known defects; how to install and render. Record the exact output dimensions, fps and frame count.

If this chat cannot attach ZIP files, say so. Provide the file tree and complete contents in clearly named blocks instead of inventing a download link. Do not say an MP4 was rendered unless you actually rendered and inspected it.


## 9. Original story development

Use STORY-WORKFLOW.md before drafting a new story. A fresh-fiction request authorizes invention within its brief, not fabrication about real people. Start with a specific protagonist, a concrete want, an obstacle, a consequential choice and a visible result. Make each scene cause the next. A twist should reinterpret a planted detail, not arrive from nowhere.

Choose horror, mystery, romance, drama, comedy or another requested genre. Do not make every story tragic. Prefer a visual action over explaining feelings in narration. Do not force a cliffhanger when the user asks for a complete standalone story.

Do not reuse existing private stories or copyrighted plots as supposedly original fiction. Keep supplied personal stories in their own continuity. Never infer a real person's identity or expose a private name; use the alias explicitly supplied by the user. Missing personal events require a question, not creative filling.

## 10. Final handoff sequence

Keep these stages separate: premise, approved story/script, action plan and asset feasibility, code project, tested render. Deliver only what was requested. A request for a skill ZIP is not permission to generate media, install software, upload assets, publish a post or operate accounts.

For the first use, follow START-HERE.txt. For a new story, use NEW-STORY-BRIEF.txt. For an existing script, use ANIMATION-JOB.txt. A tiny original example is included to show action planning, not to set the style or substitute for a complete story.
