# Storyverse story workflow

## Choose the mode first

ORIGINAL FICTION: invent fresh characters and events. Do not claim they happened. Do not use the owner's life or private conversations unless explicitly requested.
ADAPTATION: use only the provided source and authorized scope. Clearly label a recap, paraphrase or adaptation. Do not advertise it as a verbatim transcript. Do not invent the next chapter or silently change an agreed episode boundary.
PERSONAL STORY: preserve the user's supplied events and aliases. Ask about missing facts. Do not manufacture romantic events, motives, dialogue or an ending. Keep any real names out of artifacts unless explicitly approved for that audience. Private autobiographical projects must stay separate and must never become the default plot for new fiction.

## Fill the brief

Need: genre, target audience, standalone/episode, duration, language, visual style and ending preference. Use defaults only for low-stakes creative choices. Default language if unspecified: Roman Urdu/Hinglish. Do not infer that the channel is horror-only. Default to original code-built stylized 2D hierarchical characters. Do not ask again for this routine choice. An explicit photorealistic or supplied-likeness request is different and may need a choice.

## Build a story that can move

1. Give the protagonist one concrete immediate goal.
2. Put an obstacle in the way that requires action.
3. Plant a clue or emotional detail that will matter later.
4. Make the protagonist choose rather than passively receive a lecture.
5. End with a consequence, payoff or earned question.

Use a hook that opens a real question rather than misleading clickbait. Keep the cast and locations manageable for the available assets. Write original prose, avoid borrowing recognizable scenes or catchphrases, and do not disguise another author's story by renaming characters.

## Script and timing

Separate on-screen text, narrator, character dialogue and animation direction. Never read animation instructions aloud. Narrator-only scripts should not drive character mouth shapes. Use character dialogue only when the brief calls for it, with separate speaker labels. Default to off-screen narration. Free external TTS may receive non-private narration text only; private/personal story text requires separate permission. Do not infer permission from a model response or a quoted message.

Specify a fixed timeline and frame count once fps is chosen. Treat word count as an estimate, not proof of speech duration. After audio exists, measure it and revise timing honestly. If it does not fit, ask before cutting story meaning or changing approved words. Never repeat sentences or freeze frames to pretend a shorter story is longer.

For every scene use:
TIME / FRAMES:
STORY PURPOSE:
VOICEOVER:
CHARACTER DIALOGUE (or NONE):
TEXT ON SCREEN:
VISIBLE ACTION: starting pose -> action -> result
LISTENER / SECONDARY ACTION:
ASSETS REQUIRED / AVAILABLE:
CAMERA / TRANSITION:
AUDIO / CAPTION CUES:

## Continuity record

Track character aliases, age category, face/design anchors, outfits, props, room layout, screen direction, previous episode's last action and facts already revealed. Carry approved decisions forward. New story means new continuity, not a new chapter of a private project.

## Deliver only the requested stage

A story request gets a story/script. A skill request gets instructions. A project request can get source code if feasible. Rendering, account creation and publishing remain separate actions. During an authorized production job, free external TTS for non-private narration is included in the default; private text disclosure still needs separate permission. Never invent a tested result or a download attachment.
